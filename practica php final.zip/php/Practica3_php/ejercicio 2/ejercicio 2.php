<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="ej2_estilos.css">
</head>
<body>

<?php
$dado[1]='img\1.jpg';
$dado[2]='img\2.jpg';
$dado[3]='img\3.jpg';
$dado[4]='img\4.jpg';
$dado[5]='img\5.jpg';
$dado[6]='img\6.jpg';

print("<h2>Jugador 1</h2>");
$dado1=rand(1,6);
$dado2=rand(1,6);
$dado3=rand(1,6);
$dado4=rand(1,6);
$dado5=rand(1,6);
$suma1=$dado1+$dado2+$dado3+$dado4+$dado5;
print("<img src=".$dado[$dado1].">");
print("<img src=".$dado[$dado2].">");
print("<img src=".$dado[$dado3].">");
print("<img src=".$dado[$dado4].">");
print("<img src=".$dado[$dado5].">");

print("<h2>Jugador 2</h2>");
$dado6=rand(1,6);
$dado7=rand(1,6);
$dado8=rand(1,6);
$dado9=rand(1,6);
$dado10=rand(1,6);
$suma2=$dado6+$dado7+$dado8+$dado9+$dado10;
print("<img src=".$dado[$dado6].">");
print("<img src=".$dado[$dado7].">");
print("<img src=".$dado[$dado8].">");
print("<img src=".$dado[$dado9].">");
print("<img src=".$dado[$dado10].">");

if ($suma1>$suma2) {
	$ganador="ha ganado el jugador 1";
}
elseif ($suma2>$suma1) {
	$ganador="ha ganado el jugador 2";
}
elseif ($suma1=$suma2 || $suma2=$suma1) {
	$ganador="han quedado empate ambos jugadores";
}

print("<h2>Resultado</h2>\n");
print("<br>\n");
print("En conjunto, $ganador\n");
print("<br>\n");

?>

</body>
</html>