<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="ej3_estilos.css">
</head>
<body>

<?php
$nombre=$_GET['nombre'];
$telefono=$_GET['telefono'];
$ense=$_GET['ense'];
$mostrar=$_GET['mostrar'];
$matric=$_GET['matric'];

if ($mostrar=='pantalla') {
	print("El alumno <b>$nombre</b>, con número de teléfono <b>$telefono</b>, <b>$matric</b> en <b>$ense</b>.");
	}
elseif ($mostrar=='archivo') {
	$enlace=0;
	if ($_GET['enlace']==0) {
		print("<a href='datos_alumno.php?enlace=1&archivo=$archivo&linea=$linea&mostrar=$mostrar'>Mostrar archivo</a>");
	}
	else {
		$archivo = fopen("datos.txt","r");
		while(! feof($archivo)) {
	  	$linea = fgets($archivo);
	  	echo $linea. "<br>";
		}
		fclose($archivo);
	}
}		
?>
</body>
</html>