<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="ej3_estilos.css">
</head>
<body>

<?php
$enviar=$_REQUEST['enviar'];
$nombre=$_REQUEST['nombre'];
$telefono=$_REQUEST['telefono'];
$ense=$_REQUEST['ense'];
$mostrar=$_REQUEST['mostrar'];
$matric=$_REQUEST['matric'];

if (isset($enviar))
	{ 
		if ($mostrar=='pantalla') {
			if (isset($matric)==true) {
			$matric="está matriculado";
			}
			else {
				$matric="no está matriculado";
			}
			header("Location: datos_alumno.php?nombre=$nombre&telefono=$telefono&ense=$ense&mostrar=$mostrar&matric=$matric");
		}
		elseif ($mostrar=='archivo') {
			if (isset($matric)==true) {
				$matric="está matriculado";
			}
			else {
				$matric="no está matriculado";
			}
			header("Location: datos_alumno.php?nombre=$nombre&telefono=$telefono&ense=$ense&mostrar=$mostrar&matric=$matric");
			$archivo = fopen("datos.txt","w");
			fwrite($archivo, "El alumno <b>$nombre</b>, con número de teléfono <b>$telefono</b>, <b>$matric</b> en <b>$ense</b>.");
			//while(! feof($archivo)) {
			//  	$linea = fgets($archivo);
			//  	echo $linea. "<br>";
			//}
			fclose($archivo);
		}
    	
   }
   else {
?>

<form  action="ejercicio 3.php">
		<fieldset>
			<p>DATOS DEL ALUMNO:</p>
			<table>				
				<tr>
					<td class="uno">
						<br>
						<p>Introduzca su nombre:</p></td>
					<td class="dos"></td>
					<td rowspan="2" class="tres">
						Enseñanza:<br>
						<input type="radio" name="ense" value="secundaria">Secundaria
						<input type="radio" name="ense" value="bachillerato">Bachillerato
						<br>
						<input type="radio" name="ense" value="ciclo medio">Ciclo Medio
						<input type="radio" name="ense" value="ciclo superior">Ciclo Superior
					</td>
				</tr>
				<tr>
					<td class="uno"></td>
					<td class="dos"><input type="text" name="nombre"></td>
					<td></td>
				</tr>
				<tr>
					<td class="uno"><p>Introduzca su telefono:</p></td>
					<td class="dos"></td>
					<td></td>
				</tr>
				<tr>
					<td class="uno"></td>
					<td class="dos"><input type="number" name="telefono" id="num">
					Matriculado <input type="checkbox" name="matric"></td>
					<td></td>
				</tr>
				<tr>
					<td colspan="3">
						Mostrar datos
						<select name="mostrar" id="mostrar">
							<option value="pantalla">Por pantalla</option>
							<option value="archivo">En archivo datos.txt</option>
						</select>
					</td>
				</tr>
	  				
				</div>
			</table>
			
		</fieldset>
		<input type="submit" name="enviar" value="Enviar datos">		
	</form>
<?php 
	}
?>
</body>
</html>