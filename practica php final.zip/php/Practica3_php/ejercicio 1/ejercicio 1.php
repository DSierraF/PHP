<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="ej1_estilos.css">
</head>
<body>

<?php
	$dibujar=$_REQUEST['dibujar']; 	
	if (isset($dibujar))
	{
    	$alto = $_REQUEST['alto'];
    	$ancho = $_REQUEST['ancho'];
    	
	    print ("Alto: $alto\n");
	    print ("<br>");
    	print ("Ancho: $ancho\n");
    	print ("<br>");
    	print ("<br>");

			for ($f=0; $f < $alto; $f++) { 
				for ($c=0; $c < $ancho; $c++)
					
					echo "*\n";
				echo "<br>";
			}
    	
    	print ("<p><a href='ejercicio 1.php'>Nuevo dibujo</a></p>\n");
   }
   else
   {
?>
	<form action="ejercicio 1.php">
		<fieldset>
			<legend>Formulario</legend>

			<p>
				Escriba el alto y ancho (0 < números ≤ 100) y mostraré un rectángulo de estrellas de ese tamaño.
			</p>
			<p>
				<b>Ancho:</b>
				<input type="number" name="ancho" size="3" min="1" max="100">
			</p>
			<p>
				<b>Alto:</b>
				<input type="numbre" name="alto" maxlength="3" size="3" min="1" max="100">
			</p>

			<input type="submit" name="dibujar" value="Dibujar">
			<input type="reset" name="borrar" value="Borrar">
		</fieldset>		
	</form>
<?php
	}
?>

</body>
</html>