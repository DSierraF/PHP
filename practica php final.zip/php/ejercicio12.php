
<html>
<head></head>

<body>
    <?php

$contador=0;
for ($i=0;$i<5;$i++){
    $dado = rand(1,6);
    print "<p> Tirada de dado : $dado </p> \n";
    if ($dado == 4) {
        $contador++;
    }
}

print "<p> Mostramos el resultado:</p>\n";
print "<p> Han salido $contador veces el 4</p>\n";

    ?>
</body>
</html>