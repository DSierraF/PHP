<html>
<head></head>

<body>
    <?php
    $lista=["perro","gato","leon","pajaro"];
    echo "La posicion 2 de la lista es $lista[1] <br> \n";

    $lista2=[1,2,3,4];
    echo "La posicion 2 de la lista es $lista2[3] \n";

    ?>
</body>
</html>