<html>
<head></head>

<body>
    <?php
    echo "<u>hola</u> \n";
    ?>
</body>
</html>