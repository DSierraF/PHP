<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="principal_estilos.css">
</head>
<body>

<?php

$enlace=0;

if ($_GET['enlace']==1) {
	header("Location: addcita.php");
}
elseif ($_GET['enlace']==2) {
	header("Location: moscita.php");
}
elseif ($_GET['enlace']==3) {
	header("Location: buscita.php");
}
elseif ($_GET['enlace']==4) {
	print("Hola enlace 4");
}
else {
 ?>

<form action="principal.php">
	
	<a href='principal.php?enlace=1'>Añadir Cita</a><br>
	<a href='principal.php?enlace=2'>Mostrar Citas</a><br>
	<a href='principal.php?enlace=3'>Buscar por hora</a><br>
	<a href='principal.php?enlace=4'>Calcular</a>

</form>

<?php 
}
 ?>


</body>
</html>