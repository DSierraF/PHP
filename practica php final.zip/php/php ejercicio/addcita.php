<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="principal_estilos.css">
</head>
<body>

<?php

$nombre=$_REQUEST['nombre'];
$enfermedad=$_REQUEST['enfermedad'];
$fechanac=$_REQUEST['fechanac'];
$grabar=$_REQUEST['grabar'];
$hora=rand(8,20);

if (isset($grabar)) {
	header("Location: principal.php");
	$archivo = fopen("citas.txt","a");
	fputs($archivo, "$nombre:$enfermedad:$fechanac:$hora<br>".PHP_EOL);
	fclose($archivo);
}
else {
 ?>

<form action="addcita.php">
	<h2>Añadir cita</h2>
	<p>Nombre: <input type='text' name='nombre'></p>
	<p>Enfermedad: <input type='text' name='enfermedad'></p>
	<p>Fecha Nacimiento: <input type='date' name='fechanac'></p>
	<input type='submit' name='grabar' value='GRABAR'>
</form>

<?php 
}
?>
</body>
</html>