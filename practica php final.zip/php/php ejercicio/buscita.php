<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="principal_estilos.css">
</head>
<body>

<?php

$buscar=$_REQUEST['buscar'];
$horab=$_REQUEST['horab'];

if (isset($buscar)) {
	$archivo = fopen("citas.txt","r");
	while(!feof($archivo)) {
			$linea = fgets($archivo);
	 		echo $linea;
		}
		fclose($archivo);
}
else {
 ?>

<form action="buscita.php">
	<h2>Buscar cita por hora</h2>
	<p>Hora: <input type='text' name='horab'></p>
	<input type='submit' name='buscar' value='Buscar citas'>

</form>

<?php
}
?>

</body>
</html>