<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="principal_estilos.css">
</head>
<body>

<?php

$contar=0;
print("<h2>Citas para hoy</h2>");

$archivo = fopen("citas.txt","r");
while(!feof($archivo)) {
	$contar++;
	$linea = fgets($archivo);
	}
fclose($archivo);

$contar=$contar-1;
print("El médico tiene $contar citas para hoy.<br><br>");

$archivo = fopen("citas.txt","r");
while(!feof($archivo)) {
	$linea = fgets($archivo);
	print("$linea");
	}

?>
</body>
</html>