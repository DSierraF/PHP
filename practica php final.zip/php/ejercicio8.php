
<html>
<head></head>

<body>
    <?php

    $diames= rand(1,31);
    print "<p>  $diames. </p> \n";

    if ($diames < 7) {
        print "<p> Estamos a primeros de mes </p> \n";
    }
    if ($diames >= 7 && $diames<= 23) {
        print "<p> Estamos a mediados de mes </p> \n";
    }
    if ($diames > 23) {
        print "<p> Estamos a finales de mes </p> \n";
    }

    ?>
</body>
</html>