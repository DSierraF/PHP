
<html>
<head></head>

<body>
    <?php
    print "<h1> Tirada de dado </h1> \n";
    $dado = rand(1,6);
    print "<p> Ha sacado un $dado. </p> \n";

    if ($dado == 6) {
        print "<p> Has sacado la puntuacion maxima </p> \n";
    }

    else {
        print "<p> Has sacado menos de 6 </p> \n";
    }
    ?>
</body>
</html>