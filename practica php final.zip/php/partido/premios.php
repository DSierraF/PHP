
<form action=''>
MADRID: <INPUT TYPE='TEXT' name='madrid'><P>
BARCELONA: <INPUT TYPE='TEXT' name='barcelona'></p>

<input type="submit" value="Calcular" name="calculo"> 

</form>

<?php


if(isset($_REQUEST["calculo"])) {
    $file = fopen("partido.txt", "r");
    $cont = 0;
    $requestedShell = $_REQUEST[madrid] .'-'. $_REQUEST[barcelona];
    
    while(!feof($file)) {
        $linea = fgets($file);
        $arrayDatos = explode(":", $linea);
        $shell = $arrayDatos[1];


        if(trim($shell) == trim($requestedShell)) {
            $cont++;

        }

        $nombres[$i] = $array[1];
        $i++;
    }

    $total= ($i*10)/$cont;


    echo '<br>' . $total . ' euros por persona';
    fclose($file);

}




?>