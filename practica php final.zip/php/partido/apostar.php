

<?php


$nombre=$_REQUEST[nombre];
$pass=$_REQUEST[pass];
if (isset($_REQUEST[comprobar])){

if ($pass!="2asir"){
    echo "Password incorrecta";
    echo '<p> <h2><a href="entrar.php">Volver al Log in </a> </h2> </p>'; 
}
else {

    echo ' <h2> Porra online usuario activo  '.  $_REQUEST[nombre] . '</h2>';

    $nombre_archivo = "partido.txt";
    $archivo= fopen($nombre_archivo, "a"); 
    fwrite($archivo,  $_REQUEST[nombre] . ':' ); //End of line



}       

}

?>


<form action=''> 

MADRID: <INPUT TYPE='TEXT' name='madrid'><P>
BARCELONA: <INPUT TYPE='TEXT' name='barcelona'></p>

<input type="submit" value="Apostar" name="apostar"> 
<input type="button" value="Limpiar" > <br> 


</form> 



<?php
$archivo = "equipo.txt";
$fd = fopen($archivo, "r");

if (isset($_REQUEST[apostar])){

        $nombre_archivo = "partido.txt";
        $archivo= fopen($nombre_archivo, "a"); 
        fwrite($archivo,  $_REQUEST[madrid] . '-' .$_REQUEST[barcelona] . PHP_EOL); //End of line
    
    }

?>