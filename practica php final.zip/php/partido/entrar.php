

<form  action=apostar.php>


Usuario: <input type="text" name="nombre"><br>
Contraseña: <input type="password" name="pass"><br>

<input type="submit" value="Comprobar" name="comprobar"> <br> 

<form>