<a href="entrar.php"><h2>Entrar</h2></a>

<a href="premios.php"><h2>Premios</h2></a>