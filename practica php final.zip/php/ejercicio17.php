
<html>
<head>
<style>

    #resultado {
        border: 2px solid black;
        width: 5%;
        height: 5%;
        font-size: 25pt;
        text-align: center;
    }
</style>
</head>

<body>
    <?php


$contador=0;
$i=rand(1,8);
$z;

print "<h1>  $i DADOS</h1>\n";
for ($z=0; $z<10 ; $z=$z+$i)
{
    $dado = rand(1,6);
    print "<img src='./img/$dado.jpg'</p> \n";
    $contador=$contador+$dado;
}


print "<div id=resultado>  $contador </div>\n";

    ?>
</body>
</html>