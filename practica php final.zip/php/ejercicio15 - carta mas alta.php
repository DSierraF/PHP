
<html>
<head>
<style>

    #resultado {
        border: 2px solid black;
        width: 5%;
        height: 5%;
        font-size: 25pt;
        text-align: center;
    }
</style>
</head>

<body>
    <?php

$contador=0;

    $carta1 = rand(1,6);
    $carta2 = rand(1,6);
    $carta3 = rand(1,6);
    print "<img src='./img/c$carta1.svg'</p> \n";
    print "<img src='./img/c$carta2.svg'</p> \n";
    print "<img src='./img/c$carta3.svg'</p> \n";

    if ($carta1>$carta2 && $carta1>$carta3) {
        print "<p>La carta mas alta es $carta1 </p> \n";
    }
    
    if ($carta2>$carta1 && $carta2>$carta3) {
        print "<p>La carta mas alta es $carta2 </p> \n";
    }
    
    if ($carta3>$carta2 && $carta3>$carta1) {
        print "<p>La carta mas alta es $carta3 </p> \n";
    }

    $maxima= max($carta1,$carta2,$carta3);
    print "<p> $maxima </p> \n";




    ?>
</body>
</html>