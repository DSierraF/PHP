<form action="ejer2.php" method="get">
    <p>Numero: <input type="text" name="numero"></p>
    <p><input type="submit" value="Enviar"></p>
</form>