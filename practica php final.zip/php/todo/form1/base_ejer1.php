<form action="ejer1.php" method="get">
    <p>Nombre: <input type="text" name="nombre"></p>
    <p>Contraseña: <input type="password" name="pass"></p>
    <p>Edad:<input type="radio" name="edad" value="dos">Dos
    <input type="radio" name="edad" value="tres">Tres<br></p>
    <p>Gustos: <input type="checkbox" name="gustos" value="redes">Redes 
    <input type="checkbox" name="gustos" value="BBDD">BBDD</p>
    
    <p>Select:
        <select name="select[]" size="3" multiple>
        <option>Madrid</option>
        <option>Valencia</option>
        <option>Sevilla</option>
    </select></p>
    <p>Option: <input type="textbox" name="option"> </p>
    <p><input type="submit" value="Enviar"></p>
</form>