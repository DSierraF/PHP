<form action="ejer5.php" method="get">
    <?php
    $n1 = rand(1,100);
    $n2 = rand(1,10);
    print"<p> <input type='text' name='num1' size='10'  value='$n1'> / <input type='text' name='num2' size='10' value='$n2'></p>";
    print"<p> <input type='text' name='coc' size='5'>   <input type='text' name='res' size='5' ></p>";
    print"<p><input type='submit' value='Corregir'></p>";
    ?>
</form>