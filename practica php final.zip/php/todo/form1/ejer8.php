<?php
if (isset($_REQUEST['calc'])){
    print ("<h1>Convertidor de temperatura</h1>");
    
    $temp = $_REQUEST['temp'];
    $unidad = $_REQUEST['und'];
    $op1 = ($temp - 32) * 5/9;
    $op2 = ($temp * (9/5)) + 32;
    if($temp == ""){
        print("<p>Introduzca la temperatura<p>");
        print("<p>[ <a href='ejer8.php'>Volver</a> ]</p>\n");
    }
        else{
            if($unidad == ".."){
                print("<p>Seleccione la temperatura<p>");
                print("<p>[ <a href='ejer8.php'>Volver</a> ]</p>\n");

            }else{
                if($unidad == "F"){
                print("<p><b> $temp </b> Fahrenheit son <b> $op1 </b>Celsius.</p>\n");
                print("<p>[ <a href='ejer8.php'> Volver</a> ]</p>\n");

                }else{
                    if($unidad == "C"){
                        print("<p><b> $temp </b> Celsius son <b> $op2 </b> Fahrenheit.</p>\n");
                        print("<p>[ <a href='ejer8.php'>Volver</a> ]</p>\n");
                    }
                }
             }
        }
}else{
?> 
<form action="" method="get">
    <h1>Convertidor de temperatura</h1>
  
    <p>Temperatura: <input type='number' name='temp'>
    <select name="und">
        <option value="..">...</option>
        <option value="F">Fahrenheit</option>
        <option value="C">Celsius</option>
    </select></p>
    <p><input type='submit' name="calc" value='Calcular'></p>
</form>
<?php
}
?>
