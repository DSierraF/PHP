<form action="ejer3.php" method="get">
    <p>Numero 1: <input type="text" name="numero1"></p>
    <p>Numero 2: <input type="text" name="numero2"></p>
    <p>Numero 3: <input type="text" name="numero3"></p>
    <p><input type="submit" value="Enviar"></p>
</form>