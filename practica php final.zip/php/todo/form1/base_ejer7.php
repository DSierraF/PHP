<?php
if (isset($_REQUEST['buscar'])){
    print ("<h1> El formulario PHP. Resultados del formulario</h1>");
    
    $mail1 = $_REQUEST['mail1'];
    $mail2 = $_REQUEST['mail2'];
    $op = $_REQUEST['rec'];

    print("<p>Esto son los datos introducidos:</p>\n");
    print("<ul>\n");
    print("     <li>Correo 1: $mail1\n");
    print("     <li>Confirmacion correo: $mail2\n");
    print("     <li>Recibir correos: $op\n");
    print("</ul>\n");
    print("<p>[ <a href='base_ejer7.php'> Nueva busqueda</a> ]</p>\n");
}else{
?>
<form action="" method="get">
    <h1>Datos personales</h1>
  
    <p>Indique su direccion de correo electronico: <input type='text' name='mail1' size='20'></p>
    <p>Repita su direccion de correo electronico: <input type='text' name='mail2' size='20'></p>
    <p>Indique si quiere recibir correos nuestros: <select name="rec">
    <option value="..." default>...</option>
        <option value="Si">Si</option>
        <option value="No">No</option>
    </select></p>
    <p><input type='submit' name="buscar" value='Buscar'></p>
</form>
<?php
}
?>