<?php
$num1 = $_REQUEST[numero1];
$num2 = $_REQUEST[numero2];
$num3 = $_REQUEST[numero3];
$max = max($num1, $num2, $num3);
$min = min($num1, $num2, $num3);
print"<p>El numero mayor es $max</p>\n";
print"<p>El numero menor es $min </p>\n";
?>