<?php
if(isset($_REQUEST["nombre"])){
    $nombre = trim(strip_tags($_REQUEST["nombre"]));
}else{
    $nombre = "";
}

if($nombre == ""){
    print "<p>No se ha escrito nombre</p>\n";
}else{
    print "<p>Su nombre es $nombre</p>\n";
}
?>