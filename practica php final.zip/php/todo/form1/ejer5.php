<?php
$num1 = trim(strip_tags($_REQUEST[num1]));
$num2 = trim(strip_tags($_REQUEST[num2]));
$res = trim(strip_tags($_REQUEST[res]));
$coc1 = trim(strip_tags($_REQUEST[coc]));
$div = $num1 / $num2;
$coc = $num1 % $num2;
if($div == $res && $coc1 == $coc){
    print"<p>El resultado es correcto</p>";
}else{
    print"<p>El resultado es incorrecto</p>";
    print"<p>El resultado correcto es $div</p>";
    print"<p>El cociente es $coc</p>";
};

?>