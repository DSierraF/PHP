<?php
print "<pre>";
print_r($_REQUEST);
print "</pre>";
?>