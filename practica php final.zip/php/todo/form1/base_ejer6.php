<form action="ejer6.php" method="get">
    <h1>Datos personales</h1>
  
    <p>Indique su direccion de correo electronico: <input type='text' name='mail1' size='20'></p>
    <p>Repita su direccion de correo electronico: <input type='text' name='mail2' size='20'></p>
    <p>Indique si quiere recibir correos nuestros: <select name="rec">
    <option value="..." default>...</option>
        <option value="Si">Si</option>
        <option value="No">No</option>
    </select></p>
    <p><input type='submit' value='Enviar'></p>
</form>