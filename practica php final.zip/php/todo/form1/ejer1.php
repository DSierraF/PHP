<?php
print"<p>Su nombre es " . $_REQUEST[nombre] . "</p>\n";
print"<p>Su contraseña es " . $_REQUEST[pass] . "</p>\n";
print"<p>Su edad es " . $_REQUEST[edad] . "</p>\n";
print"<p>Su gusto es " . $_REQUEST[gustos] . "</p>\n";
print"<p>Su select es " . $_REQUEST[select][0] . "</p>\n";
print"<p>Su option es " . $_REQUEST[option] . "</p>\n";
?>