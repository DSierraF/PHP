<form action="form4.php" method="get">
    <p>Nombre: <input type="text" name="nombre"></p>
    <p>Apellidos: <input type="text" name="apellidos"></p>
    <p>Contraseña: <input type="password" name="pass"></p>
    <select name="menu[]" size="3" multiple>
        <option>Op 1</option>
        <option>Op 2</option>
        <option>Op 3</option>
        <option>Op 4</option>
    </select><br>
    <input type="radio" name="radioej" value="Uno">Uno
    <input type="radio" name="radioej" value="Dos">Dos
    <p><input type="submit" value="Enviar"></p>
</form>