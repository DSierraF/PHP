<form action="ejer4.php" method="get">
    <?php
    $n1 = rand(1,9);
    $n2 = rand(1,9);
    print"<p> <input type='text' name='num1' size='10' style='margin-left:12px' value='$n1'></p>";
    print"<p>x <input type='text' name='num2' size='10' value='$n2'></p>";
    print"<p> <input type='text' name='res' size='5' style='margin-left:12px''></p>";
    print"<p><input type='submit' value='Corregir'></p>";
    ?>
</form>