<?php
$num1 = isset($_REQUEST[num1]);
$num2 = $_REQUEST[num2];
$res = $_REQUEST[res];
$mult = $num1 * $num2;
if($mult == $res){
    print"<p>El resultado es correcto</p>";
}else{
    print"<p>El resultado es incorrecto</p>";
    print"<p>El resultado correcto es $mult</p>";
};


?>