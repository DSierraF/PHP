<?php
$correo1 = $_REQUEST[mail1];
$correo2 = $_REQUEST[mail2];
if($correo1 == "" || $correo1 == "" || $_REQUEST[rec] == "..."){
    print"No completó todos los campos";
}else{
    if($correo1 == $correo2 && $_REQUEST[rec] == Si){
        print"Su correo es $correo1 y <b>SI</b> quiere recibir correos nuestros.";
    }else{
        if($correo1 == $correo2 && $_REQUEST[rec] == No){
            print"Su correo es $correo1 y <b>NO</b> quiere recibir correos nuestros.";
        }else{
            print"<p>Los correos no coinciden</p>";
        }
    }
}
?>