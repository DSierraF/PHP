<?php

for($x=1; $x<11; $x++){
    $numero = $_REQUEST[numero];
    $op = $numero * $x;
    print"" . $_REQUEST[numero] . "x $x = $op<br>";
}

?>