<?php
print "<p>Su nombre es " . $_REQUEST['nombre'] . "<p>\n";
print "<p>Sus apellidos son " . $_REQUEST['apellidos'] . "<p>\n";
print "<p>Su contraseña es " . $_REQUEST['pass'] . "<p>\n";
print "<p>Su menu es " . $_REQUEST['menu'][0] . "<p>\n";
print "<p>Su opcion es " . $_REQUEST['radioej'] . "<p>\n";
?>