<?php
if(trim($_REQUEST['nombre']) == ""){
    print"<p>El nombre esta vacio</p>\n";
}else{
    print"<p>Su nombre es " . $_REQUEST['nombre'] . "</p>\n";
    print"<p>La longitud de la contraseña es ". strlen($_REQUEST['pass']) . "</p>\n";
};

if($_REQUEST['apellidos'] == ""){
    print"El apellido esta vacio";
}else{
    print"<p>Sus apellidos son " . $_REQUEST['apellidos'] . "</p>\n";
};

?>