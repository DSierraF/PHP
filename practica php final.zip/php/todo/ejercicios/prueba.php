<?php
$archivo = "baloncesto.txt";
$fd = fopen($archivo, "r");
$i=0;

while( (($linea=fgets($fd)) !== false)){
    $array = explode(";", $linea);
    $nombres[$i] = $array;
    $i++;
    
    }
fclose($fd);
echo"<br><br>El numero de elementos en el array es: " . count($nombres) . "<br>";
sort($nombre);
for($i=0;$i<=count($nombres);$i++){
    echo " $nombres[$i] <br> ";
}
?>