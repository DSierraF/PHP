<?php
$archivo = "baloncesto.txt";
$fd = fopen($archivo, "r");
?>
<form action="" method="get">
    <h1>Equipos ACB</h1>
  
    <p>Ciudad: 
    <select name="ciud1">
        <option value="">...</option>
        <option value="MADRID">Madrid</option>
        <option value="BARCELONA">Barcelona</option>
        <option value="MALAGA">Malaga</option>
        <option value="MURCIA">Murcia</option>
        <option value="VITORIA">Vitoria</option>
    </select>
    </p>
    <p>Ciudad:<input type="text" name="ciud2"</p>
    <p><input type='submit' name="calc" value='Calcular'></p>
</form>
<?php
while( (($linea=fgets($fd)) !== false)){
    $array = explode(";", $linea);

    $codigo = $array[0];
    $nombre = $array[1];
    $ciudad = $array[2];
    if((trim($ciudad) == trim(strtoupper($_REQUEST[ciud2])))){
        echo "<b>Codigo</b>: $codigo";
    echo "   <b>Nombre</b>: $nombre";
    echo "   <b>Ciudad</b>: $ciudad <br>";
    }else{if((($_REQUEST[ciud2]) == "") && (trim($ciudad) == ($_REQUEST[ciud1]))){
            echo "<b>Codigo</b>: $codigo";
        echo "   <b>Nombre</b>: $nombre";
        echo "   <b>Ciudad</b>: $ciudad <br>";
        }
        
        }
}
fclose($fd);
?>

