<?php 
$animales = [
    ["Caballo", "caballo.png", "https://es.wikipedia.org/wiki/Camelus"],
    ["Elefante", "elefante.png", "https://es.wikipedia.org/wiki/Eliphantidae"],
    ["Jirafa", "jirafa.png", "https://es.wikipedia.org/wiki/Giraffa_camelopardalis"],
    ["Oso", "oso.png", "https://es.wikipedia.org/wiki/Ursidae"],
    ["Pájaro", "pajaro.png", "https://es.wikipedia.org/wiki/Aves"],
    ["Pez", "pez.png", "https://es.wikipedia.org/wiki/Pez"],
    ["Perro", "perro.png", "https://es.wikipedia.org/wiki/Canis_familiaris"],
    ["Gato", "gato.png", "https://es.wikipedia.org/wiki/Felis_silvestris_catus"],
];
$animal = rand(0, count($animales) - 1);
print"<h2>" . $animales[$animal][0] . "</h2>\n";
print"<p><img src='./img2/{$animales[$animal][1]}' height=100</p>\n";
print"<p> Mas <a href='{$animales[$animal][1]}' informacion sobre este animal</a> en la Wikipedia</p>\n";
?>

