<?php
$nombre = ["caballo", "elefante", "gato", "jirafa", "oso", "pajaro", "perro", "pez"];
$animal = rand(1,7);
print " <p><img src='/img2/$nombre.png' height=150></p>\n";
print "<p>Ha sacado un <strong>$nombre[$animal]</strong>.</p>\n";
?>