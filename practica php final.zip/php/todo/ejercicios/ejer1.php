<?php 
$edad = 88;
$calculo = $edad * 2;
print "<p>La edad de Pepe es $edad y el x2 es $calculo</p>";

$cadena1 = "Barcelona";
$cadena2 = "Palancas";
$cadena3 = $cadena1 . $cadena2;
print "<p>$cadena3</p>";

$x = 2;
$y = 4;
$suma = $x + $y;
$producto = $x * $y;
$potencia = pow($x, $y);
print "<p>Suma: $x + $y = $suma</p>\n";
print "<p>Producto: $x + $y = $producto</p>\n";
print "<p>Potencia: $x + $y = $potencia</p>\n";

$lista = ["casa", "perro", "manzana", "pera", "9"];
print"<p>El valor de la posicion de la lista es $lista[3]</p>\n";

$lista2 = [6, 8, 9 ,10];
print"<p>El valor de la posicion de la lista es $lista2[3]</p>\n";

define("PI", 3.14);
print"<p>El valor de pi es" . PI . "</p>\n";

$valor = 9;
$valor++;
print"<p>" . $valor++ . "</p>\n";
print"<p>" . $valor-- . "</p>\n";


$numero = 4.3;
print"<p> El numero es " . $numero . "</p>";
$numero1 = round($numero);
print"<p> Round " . $numero1 . "</p>";
$numero2 = floor($numero);
print"<p> Floor " . $numero2 . "</p>";
$numero3 = Ceil($numero);
print"<p> Ceil " . $numero3 . "</p>";
?>
