<head>
    <style>
        fieldset{
            background-color:  #E2DCFF;
            border-color: #8A72FD;
        }
        legend{
            background-color: white;

            border: solid #8A72FD;
        }
        input.num{
            width: 35px;
        }
    </style>
</head>
<body>
    <form action="" method="get">
        <fieldset>
            <legend>Formulario</legend>
            <p>Escriba el alto y ancho (0 < números ≤ 100) y mostraré un rectángulo de estrellas de ese tamaño.</p>
            <p><b>Alto:</b> <input type='number' class='num' name='alto'></p>
            <p><b>Ancho:</b> <input type='number' class='num' name='ancho'></p>
            <p><input type='submit' name='dib' value='Dibujar'> <input onClick='borrar' type='reset' name='bor' value='Borrar'></p>
        </fieldset>  
    </form>
</body>
<?php
$alto = $_REQUEST["alto"];
$ancho = $_REQUEST["ancho"];

if($alto == "" || $ancho == ""){
    print"Introduzca valores para alto y ancho.";
}else{
    if($alto > 0 && $alto <= 100 && $ancho > 0 && $ancho <= 100){ 
        print"Alto: " . $alto . "<br>";
        print"Ancho: " . $ancho . "<br>";
        for ($i=1; $i<=$alto; $i++){
            for ($j=1; $j<=$ancho; $j++){
                print"* ";
            }

            print"<br>";
        }
    }else{
        if($alto < 0 || $alto > 100 || $ancho < 0 || $ancho > 100)
        print"Introduzca un numero dentro del rango válido, entre 1 y 100.";
    }
}


?>