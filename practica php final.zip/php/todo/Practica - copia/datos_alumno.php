<?php


if(trim($_REQUEST[nomb]) == "" || trim($_REQUEST[telf]) == ""){
     print "Rellene el formulario";
}else{
    $fich= fopen("alumnos.txt", "a");
    fputs($fich, "El alumno " . trim($_REQUEST[nomb]) .", con teléfono ". trim($_REQUEST[telf]) .", está matriculado en ". $_REQUEST[ens] .".". PHP_EOL);
    fclose($fich);
}


if($_REQUEST[dat] == "txt"){
    print"<a href='mostrar_datos.php'>Mostrar datos</a><br>";
    print"<a href='Practica3_ejer3.php'>Volver</a>";
}else{
    if($_REQUEST[dat] == "pant"){
        print"El alumno " . trim($_REQUEST[nomb]) .", con teléfono ". trim($_REQUEST[telf]) .", está matriculado en ". $_REQUEST[ens] .".";
        print"<br><a href='Practica3_ejer3.php'>Volver</a>";
    }
}

?>