
<html>
<head></head>

<body>
    <?php

print "<h1>  COMIENZO </h1> \n";

for  ($i=1; $i<=9; $i=$i+2) {
    print "<p> $i</p> \n";
}

print "<h1>  FINAL </h1> \n";

    ?>
</body>
</html>