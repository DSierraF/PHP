<html>
<head></head>

<body>
    <?php
    $edad=88;
    print "La edad de Pepe es $edad <br> \n";

    $radio =12;
    $perimetro = 
    2 * 3.14 * $radio;
    echo "El valor es $perimetro"
    ?>
</body>
</html>