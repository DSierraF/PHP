<?php
session_start();
$sesion=$_SESSION['correo'];
unset($sesion);
session_destroy();
header('Location: ../inmo3/');
?>