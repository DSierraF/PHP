<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Inmobiliaria</title>
	<link rel="stylesheet" type="text/css" href="../estilos.css">
</head>
<body>

<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				<h3>Bienvenido al menu de vendedor</h3>

				<br>

				<h4>Dar de alta mi piso</h4>
				<a href="insertar1.php">Alta</a>
				<br>

				<br>
				<a href='../index.php'>Volver a página principal</a>
				<?php 
				$conexion = mysqli_connect("localhost", "root", "css99");
					mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");


					$codigo=$_REQUEST['codigo'];
					$compcod = "SELECT * FROM pisos WHERE codigo_piso=$codigo";

					$resultado = $conexion-> query($compcod);
					$contar = mysqli_num_rows($resultado);

					if ($contar == 1) {
					print("Este codigo ya existe");
					print("<br><br>");
					print("<b><a href='insertar1.php'>Vuelve a intentarlo con otro</a></b>");
					print("<br>");
					}
					else {

					$codigo=$_POST['codigo'];
					$calle=$_POST['calle'];
					$numero=$_POST['numero'];
					$piso=$_POST['piso'];
					$puerta=$_POST['puerta'];
					$cp=$_POST['cp'];
					$metros=$_POST['metros'];
					$zona=$_POST['zona'];
					$precio=$_POST['precio'];
					$usuario_id=$_POST['id'];
					$imagen=$_FILES['imagen']['name'];

					$directorio='../imagenes_pisos/';
					$subirimagen=$directorio.basename($_FILES['imagen']['name']);
					if (move_uploaded_file($_FILES['imagen']['tmp_name'], $subirimagen)) {

						$query = "INSERT INTO pisos VALUES($codigo,'$calle',$numero,$piso,'$puerta',$cp,$metros,'$zona',$precio,'$imagen',$usuario_id);";

					 	if (mysqli_query($conexion, $query)) {
					 		print("Piso añadido correctamente.");
					 	}
					 	else {
							print("Fallo al añadir el piso: ". $query . "<br>" . mysqli_error($conexion));
						}
					} else {
						print("La imagen no se ha podido subir, vuelva a intentarlo.");
					}
					}					
				mysqli_close($conexion);
				?>
</div>

</body>
</html>