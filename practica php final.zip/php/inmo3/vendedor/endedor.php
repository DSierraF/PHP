<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Inmobiliaria</title>
	<link rel="stylesheet" type="text/css" href="../estilos.css">
</head>
<body>

<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				<h3>Bienvenido al menu de vendedor</h3>

				<br>

				<h4>Dar de alta mi piso</h4>
				<a href="insertar1.php">Alta</a>
				<br>

				<br>
				<a href='../index.php'>Volver a página principal</a>
</div>

</body>
</html>