<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Insertar</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../estilos.css">
</head>
<body>

<div id="contenedor">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				<h3>Bienvenido al menu de vendedor</h3>

				<br>

				<h4>Dar de alta mi piso</h4>
				<a href="insertar1.php">Alta</a>
				<br>

				<br>
				<a href='../index.php'>Volver a página principal</a>


				
				<h1>Alta nuevo piso</h1>
				<br>

				<form action="insertar2.php" enctype="multipart/form-data" method="post" >
				 <p>* Código del piso: <input type="number" name="codigo"></p> 
				<br>
				<p>* Calle: <input type="text" name="calle"></p>
				<br>
				<p>* Número del edificio: <input type="number" name="numero"></p>
				<br>
				<p>* Piso: <input type="number" name="piso"></p>
				<br>
				<p>* Puerta: <input type="puerta" name="puerta"></p>
				<br>
				<p>* Código postal: <input type="number" name="cp"></p>
				<br>
				<p>* Metros: <input type="number" name="metros"></p>
				<br>
				<p>Zona: <input type="text" name="zona"></p>
				<br>
				<p>* Precio: <input type="number" name="precio"></p>
				<br>
				<p>* Introduzca una imágen del piso: <input type="file" name="imagen"></p>
				<br>
				<p>Id del vendedor <input type="number" name="id" value="0"></p>
				<br>
				<p><b>Rellene los campos con un  *</b></p>
				<br>
				<input type="submit" name="enviar" value="Enviar">
				<input type="reset" value="Borrar">
				</form>
</div>



</div>

</body>
</html>