<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Inmobiliaria</title>
	<link rel="stylesheet" type="text/css" href="../estilos.css">
</head>
<body>


<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				
				<form action="comprar.php" method="get" >
				<h4>Buscar piso</h4>
				<p>Por código</p>
				<p><input type="number" name="codigo" placeholder="Introduzca el código"></p>
				<input type="submit" name="buscar" value="Buscar">
				<br>
				</form>
				
				<form action="ver.php" method="get" >
				<p>Por zona</p>
				<p><input type="text" name="zona" placeholder="Introduzca la zona"></p>
				<input type="submit" name="buscar" value="Buscar">
				<br>
				</form>
				<br>
				<a href='../index.php'>Volver a página principal</a>


				
				<?php

				$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");


				$codigo=$_REQUEST['codigo'];
				$zona=$_REQUEST['zona'];

					$buscazon = "SELECT * FROM pisos WHERE zona='$zona';";

					$resultzon = mysqli_query($conexion,$buscazon);
					
					if (mysqli_num_rows($resultzon)>0) {
						if (strlen($zona)==0) {

									print("En esta sección no puede buscar pisos sin zona.");

								} 
							else {

								while ($row=mysqli_fetch_assoc($resultzon)) {
								print("<table id='pisos'>");
								print("<tr>");
								print("<td id='piso_img' background='../imagenes_pisos/".$row['imagen']."'></td>");
								print("<td id='piso_inf'>

										<h2>Información:</h2>
										<ul class='present'>");
								
									print("

											<li><b>Zona donde se encuentra</b>: ".$row['zona']."</li>
											<li><b>Calle</b>: ".$row['calle']."</li>
											<li><b>Número del edificio</b>: ".$row['numero']."</li>
											<li><b>Número del piso</b>: ".$row['piso']."</li>
											<li><b>Puerta</b>: ".$row['puerta']."</li>
											<li><b>Metros cuadrados</b>: ".$row['metros']."m2</li>
										
										</ul>
										<br>
										<h2>Precio: ".$row['precio']."€</h2>


										</td>");
	
								
									print("<td class='comprar'>");


											$sesion = mysqli_query($conexion, "SELECT * FROM usuario WHERE correo='$_SESSION[correo]'");

											$fila = mysqli_fetch_assoc($sesion);

											$tipouser = $fila['tipo_usuario'];

											$compcod = "SELECT * FROM comprados WHERE codigo_piso='$row[Codigo_piso]' ";

											$resultadocod = $conexion-> query($compcod);
											$contarcod = mysqli_num_rows($resultadocod);

											if ($contarcod == 1) {

												print("<p class='comprar'>PISO</p><p class='comprar'>VENDIDO</p>
															<br>");

											} else {
												if ($tipouser=="comprador" || $tipouser=="administrador") {
													print("

													<form action='comprar.php' method='get'>
														<input type='text' name='codigo' value='".$row['Codigo_piso']."' style='display:none'>
														<input type='submit' name='comprar' value='VER PISO' class='comprar'>
													</form>

													");
												}

											}											

										print("</td>");

								print("</tr>");
							print("</table>");
							print("<br>");
							}
						} 
					} else {
							print("No existe ningún piso con esos parámetros, inténtelo con otro.");
						}
						
				mysqli_close($conexion);
				?></div>

	

</div>

</body>
</html>