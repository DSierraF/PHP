<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Inmobiliaria</title>
	<link rel="stylesheet" type="text/css" href="../estilos.css">
</head>
<body>


<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				
				<form action="comprar.php" method="get" >
				<h4>Buscar piso</h4>
				<p>Por código</p>
				<p><input type="number" name="codigo" placeholder="Introduzca el código"></p>
				<input type="submit" name="buscar" value="Buscar">
				<br>
				</form>
				
				<form action="ver.php" method="get" >
				<p>Por zona</p>
				<p><input type="text" name="zona" placeholder="Introduzca la zona"></p>
				<input type="submit" name="buscar" value="Buscar">
				<br>
				</form>
				<br>
				<a href='../index.php'>Volver a página principal</a>


				
				<?php

				$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");


				$codigo=$_REQUEST['codigo'];

				$existe="SELECT * FROM comprados WHERE codigo_piso='$codigo';";

				$resultado = $conexion-> query($existe);
				$contar = mysqli_num_rows($resultado);

				if ($contar == 1) {
					print("Este piso ya está comprado, disculpe las molestias");
				}
				else {

					$usuariocom = "SELECT usuario_id FROM usuario WHERE correo='$_SESSION[correo]';";
					$resultcom = mysqli_query($conexion,$usuariocom);
					$row=mysqli_fetch_assoc($resultcom);

					$usuario_id=$row['usuario_id'];
					$precio=$_REQUEST['precio'];
					$query = "INSERT INTO comprados VALUES ($usuario_id, $codigo, $precio)";

						if (mysqli_query($conexion, $query)) {
							print("Piso comprado con éxito.");
						}
						else {
							print("Fallo al comprar el piso: ". $query . "<br>" . mysqli_error($conexion));
						}

				}
						
				mysqli_close($conexion);
				?></div>

	

</div>

</body>
</html>