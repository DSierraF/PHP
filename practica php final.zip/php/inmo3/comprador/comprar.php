<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Inmobiliaria</title>
	<link rel="stylesheet" type="text/css" href="../estilos.css">
</head>
<body>


<div id="contenedor">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				
				<form action="comprar.php" method="get" >
				<h4>Buscar piso</h4>
				<p>Por código</p>
				<p><input type="number" name="codigo" placeholder="Introduzca el código"></p>
				<input type="submit" name="buscar" value="Buscar">
				<br>
				</form>
				
				<form action="ver.php" method="get" >
				<p>Por zona</p>
				<p><input type="text" name="zona" placeholder="Introduzca la zona"></p>
				<input type="submit" name="buscar" value="Buscar">
				<br>
				</form>
				<br>
				<a href='../index.php'>Volver a página principal</a>


				
				<?php

				$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");


				$codigo=$_REQUEST['codigo'];

						
					$buscacod = "SELECT * FROM pisos WHERE codigo_piso=$codigo;";

					$resultcod = mysqli_query($conexion,$buscacod);
					
					$row=mysqli_fetch_assoc($resultcod);

					if (mysqli_num_rows($resultcod)>0) {

								print("<h1>Detalles finales del piso</h1><br>");
								print("

								<table class='comprar'>
									<tr class='img_comprar'>
										<td colspan='5' class='img_comprar'><img src='../imagenes_pisos/".$row['imagen']."' class='img_comprar'></td>
									</tr>
									<tr class='medio'>
										<td colspan='5'></td>
									</tr>
									<tr>
										<td class='descripcionarriba'>Calle</td>
										<td class='descripcionarriba'>Número del edificio</td>
										<td class='descripcionarriba'>Número del piso</td>
										<td class='descripcionarriba'>Puerta</td>
										<td class='descripcionarriba'>Metros cuadrados</td>
									</tr>

									<tr>
										<td class='datosabajo'>".$row['calle']."</td>
										<td class='datosabajo'>".$row['numero']."</td>
										<td class='datosabajo'>".$row['piso']."</td>
										<td class='datosabajo'>".$row['puerta']."</td>
										<td class='datosabajo'>".$row['metros']."</td>
									</tr>
									<tr class='medio'>
										<td colspan='5'></td>
									</tr>
									<tr class='medio'>
										<td colspan='5'></td>
									</tr>
									<tr class='img_comprar'>
										<td colspan='5'><h2>Precio final - ".$row['precio']."€</h1></td>
									</tr>
									<tr class='medio'>
										<td colspan='5'></td>
									</tr>
									<tr class='boton_comprar'>
										<td colspan='5' class='boton_comprar'>");

											$sesion = mysqli_query($conexion, "SELECT * FROM usuario WHERE correo='$_SESSION[correo]'");

											$fila = mysqli_fetch_assoc($sesion);

											$tipouser = $fila['tipo_usuario'];

											$compcod = "SELECT * FROM comprados WHERE codigo_piso='$row[Codigo_piso]' ";

											$resultadocod = $conexion-> query($compcod);
											$contarcod = mysqli_num_rows($resultadocod);

											if ($contarcod == 1) {

												print("<p class='comprar'>PISO</p><p class='comprar'>VENDIDO</p>
															<br>");

											} else {
												if ($tipouser=="comprador") {
													print("

													<form action='comprar2.php' method='get'>
														<input type='number' name='codigo' value='".$row['Codigo_piso']."' style='display:none'>
														<input type='number' name='precio' value='".$row['precio']."' style='display:none'>
														<input type='submit' name='comprar' value='COMPRAR' class='comprar'>
													</form>

													");
												} else if ($tipouser=="administrador") {
													print("

													<input type='button' onclick='mensaje()' value='COMPRAR' class='comprar'/>

													");
												}

											}	
											

										print("</td>
									</tr>
								</table>

								");

					}
					 else {
							print("No existe ningún piso con esos parámetros, inténtelo con otro.");
						}
						
				mysqli_close($conexion);
				?></div>

	

</div>

</body>
</html>