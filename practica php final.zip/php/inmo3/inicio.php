<?php 
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Inicio de sesión</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>

<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="logeo">
					<p><a class="inicio" href="logearse.php">Iniciar sesión</a></p>
				</td>
				<td class="creacion">
					<p><a class="inicio" href="inicio.php">Crear usuario</a></p>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				<?php

				$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");


				$resultado = mysqli_query($conexion, "SELECT * FROM usuario WHERE correo='$_SESSION[correo]'");

				$row = mysqli_fetch_assoc($resultado);
						
						$tipouser = $row['tipo_usuario'];
				?>
						
				<h1>Crear nuevo usuario</h1>
				<br>
				<?php
						if ($tipouser=="vendedor") {
					print("Bienvenido,  ".$row['nombres']);
					print("<br>");
					print("<a href='vendedor\endedor.php'>Ir a la página principal</a><br>");
				} else {
					if ($tipouser=="comprador") {
						print("Bienvenido,  ".$row['nombres']);
						print("<br>");
						print("<a href='comprador\comprador.php'>Ir a la página principal</a><br>");			
					} else {
						if ($tipouser=="administrador") {
							print("Bienvenido,  ".$row['nombres']);
							print("<br>");
							print("<a href='administrador\administrador.php'>Ir a la página principal</a><br>");				
						} 
					}
				}
				?>
				<form method="get" action="crear.php" >
					Nombre: <input type="text" name="usuario"> <br><br>
					Correo: <input type="text" name="correo"> <br><br>
					Contraseña: <input type="password" name="clave"> <br><br>
					Tipo de usuario: 
					<input type="radio" name="tipouser" value="comprador"> Comprador
					<input type="radio" name="tipouser" value="vendedor"> Vendedor
					<br><br>
					<input type="submit" name="enviar" value="Enviar">
				</form>

			</td>

		</tr>

	</table>


</div>

</body>
</html>