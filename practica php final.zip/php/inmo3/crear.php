<!DOCTYPE html>
<html>
<head>
	<title>Creación usuario</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>

<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="logeo">
					<p><a class="inicio" href="logearse.php">Iniciar sesión</a></p>
				</td>
				<td class="creacion">
					<p><a class="inicio" href="inicio.php">Crear usuario</a></p>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				<?php

				$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");


				$resultado = mysqli_query($conexion, "SELECT * FROM usuario WHERE correo='$_SESSION[correo]'");

				$row = mysqli_fetch_assoc($resultado);
						
						$tipouser = $row['tipo_usuario'];

						if ($tipouser=="vendedor") {
					print("Bienvenido,  ".$row['nombres']);
					print("<br>");
					print("<a href='vendedor\endedor.php'>Ir a la página principal</a><br>");
				} else {
					if ($tipouser=="comprador") {
						print("Bienvenido,  ".$row['nombres']);
						print("<br>");
						print("<a href='comprador\comprador.php'>Ir a la página principal</a><br>");			
					} else {
						if ($tipouser=="administrador") {
							print("Bienvenido,  ".$row['nombres']);
							print("<br>");
							print("<a href='administrador\administrador.php'>Ir a la página principal</a><br>");				
						} 
					}
				}
				?>


				
				<?php 
	
					$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");


					$compcorreo = "SELECT * FROM usuario WHERE correo='$_REQUEST[correo]' ";

					$resultado = $conexion-> query($compcorreo);
					$contar = mysqli_num_rows($resultado);

					if ($contar == 1) {
					print("<h3>Este correo ya existe</h3>");
					print("<br>");
					print("<a href='inicio.php'>Vuelve a intentarlo con otro</a>");
					print("<br>");
					print("<a href='logearse.php'>Accede con el  usuario ya registrado</a>");
					}
					else {

					$usuario = $_REQUEST['usuario'];
					$correo = $_REQUEST['correo'];
					$clave = $_REQUEST['clave'];
					$enc = MD5('$clave');
					$tipouser = $_REQUEST['tipouser'];

					//Enviar el usuario, correo y contraseña a la base de datos.
					$query = "INSERT INTO usuario VALUES (NULL,'$usuario', '$correo', '$enc', '$tipouser')";

					if (mysqli_query($conexion, $query)) {
						print("Cuenta creada correctamente.");
						print("<br>");
						print("<a href='logearse.php'>Accede con el  usuario ya registrado</a>");
					}
					else {
						print("Fallo al crear la cuenta: ". $query . "<br>" . mysqli_error($conn));
					}

					}
					mysqli_close($conexion);
				?>

			</td>

		</tr>

	</table>


</div>

</body>
</html>