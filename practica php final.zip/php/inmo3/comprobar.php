<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Comprobación inicio sesión</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>

<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="logeo">
					<p><a class="inicio" href="logearse.php">Iniciar sesión</a></p>
				</td>
				<td class="creacion">
					<p><a class="inicio" href="inicio.php">Crear usuario</a></p>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				<?php

					$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");


					$correo = $_REQUEST['correo'];
					$clave = $_REQUEST['clave'];
					$enc = MD5('$clave');

					$resultado = mysqli_query($conexion, "SELECT * FROM usuario WHERE correo='$correo'");

					$row = mysqli_fetch_assoc($resultado);

					$bddenc = $row['clave'];
					if ($enc==$bddenc) {
						$_SESSION['correo'] = $row['correo'];
						
						$tipouser = $row['tipo_usuario'];

						if ($tipouser=="administrador") {
							print("Bienvenido,  <b>".$row['nombres']."</b>");
							print("<br><br>");
							print("<a href='administrador/administrador.php'>Ir a la página del administrador</a>");
						}
						else if ($tipouser=="vendedor") {
							print("Bienvenido,  <b>".$row['nombres']."</b>");
							print("<br><br>");
							print("<a href='vendedor/endedor.php'>Ir a la página del vendedor</a>");
						}
						else if ($tipouser=="comprador") {
							print("Bienvenido,  <b>".$row['nombres']."</b>");
							print("<br><br>");
							print("<a href='index.php'>Ir a la página principal</a><br>");
						}
					}
					else {
						print("<h3>Error al iniciar sesion</h3>");
						print("<br>");
						print("<p>Puede volver a intentarlo</p>");
						print("<br>");
						print("<p><b><a href='logearse.php'>Volver a intentarlo</a></b></p>");
					}
				?>

			</td>

		</tr>

	</table>
	

</div>

</body>
</html>