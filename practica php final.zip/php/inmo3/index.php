<?php 
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Inmobiliaria</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>

<div id="contenedor">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="logeo">
					<p><a class="inicio" href="logearse.php">Iniciar sesión</a></p>
				</td>
				<td class="creacion">
					<p><a class="inicio" href="inicio.php">Crear usuario</a></p>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				<?php

				$conexion = mysqli_connect("localhost", "root", "css99");
					mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");


				$resultado = mysqli_query($conexion, "SELECT * FROM usuario WHERE correo='$_SESSION[correo]'");

				$row = mysqli_fetch_assoc($resultado);
						
						$tipouser = $row['tipo_usuario'];
				?>
	


				
				<h1 class="titulo"><u>PISOS EN VENTA</u></h1>
				<?php
						if ($tipouser=="vendedor") {
					print("Bienvenido,  ".$row['nombres']);
					print("<br>");
					print("<a href='vendedor/endedor.php'>Ir a la página principal</a><br>");
				} else {
					if ($tipouser=="comprador") {
						print("Bienvenido,  ".$row['nombres']);
						print("<br>");
						print("<a href='comprador\comprador.php'>Ir a la página principal</a><br>");			
					} else {
						if ($tipouser=="administrador") {
							print("Bienvenido,  ".$row['nombres']);
							print("<br>");
							print("<a href='administrador\administrador.php'>Ir a la página principal</a><br>");				
						} 
					}
				}

				$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");


				

				$pisos= "SELECT * FROM pisos";

				$resultado = mysqli_query($conexion, $pisos);

				if (mysqli_num_rows($resultado)>0) {

					while ($row=mysqli_fetch_assoc($resultado)) {

						print("<table id='pisos'>");
							print("<tr>");
								print("<td id='piso_img' background='imagenes_pisos/".$row['imagen']."'></td>");
								print("<td id='piso_inf'>

										<h2>Información:</h2>
										<ul class='present'>");
								if (strlen($row['zona'])==0) {

									print("

											<li><b>Calle</b>: ".$row['calle']."</li>
											<li><b>Número del edificio</b>: ".$row['numero']."</li>
											<li><b>Número del piso</b>: ".$row['piso']."</li>
											<li><b>Puerta</b>: ".$row['puerta']."</li>
											<li><b>Metros cuadrados</b>: ".$row['metros']."m2</li>
										
										</ul>
										<br>
										<h2>Precio: ".$row['precio']."€</h2>


										</td>");
								} else {
									print("

											<li><b>Zona donde se encuentra</b>: ".$row['zona']."</li>
											<li><b>Calle</b>: ".$row['calle']."</li>
											<li><b>Número del edificio</b>: ".$row['numero']."</li>
											<li><b>Número del piso</b>: ".$row['piso']."</li>
											<li><b>Puerta</b>: ".$row['puerta']."</li>
											<li><b>Metros cuadrados</b>: ".$row['metros']."m2</li>
										
										</ul>
										<br>
										<h2>Precio: ".$row['precio']."€</h2>


										</td>");
	
								}
									print("<td class='comprar'>");

											$sesion = mysqli_query($conexion, "SELECT * FROM usuario WHERE correo='$_SESSION[correo]'");

											$fila = mysqli_fetch_assoc($sesion);

											$tipouser = $fila['tipo_usuario'];

											$compcod = "SELECT * FROM comprados WHERE codigo_piso='$row[Codigo_piso]' ";

											$resultadocod = $conexion-> query($compcod);
											$contarcod = mysqli_num_rows($resultadocod);

											if ($contarcod == 1) {

												print("<p class='comprar'>PISO</p><p class='comprar'>VENDIDO</p>
															<br>");

											} else {
												if ($tipouser=="comprador" || $tipouser=="administrador") {
													print("

													<form action='comprador/comprar.php' method='get'>
														<input type='text' name='codigo' value='".$row['Codigo_piso']."' style='display:none'>
														<input type='submit' name='comprar' value='VER PISO' class='comprar'>
													</form>

													");
												} else {
													print("<p class='comprar'>Para comprar necesita ser un usuario tipo COMPRADOR.</p>
															<br>");
												}

											}
										print("</td>");			
							print("</tr>");
						print("</table>");
						print("<br>");

					}

				} else {
					print("Parece que la página no tiene pisos que listar.");
					print("<br>");
					print("Disculpe las molestias");
				}
				mysqli_close($conexion);
				?>
				
			</td>
			
		</tr>

	</table>
	

</div>

</body>
</html>