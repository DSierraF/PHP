<?php 
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Borrar</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../../estilos.css">
</head>
<body>

<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				<h3>Bienvenido al menú del administrador</h3>

				<br>

				<h4>Usarios:</h4>
				<li class="noestilo"><a href="listar.php">Listar</a></li>
				<li class="noestilo"><a href="insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="modificar1.php">Modificar</a></li>

				<br>

				<h4>Pisos:</h4>
				<li class="noestilo"><a href="../pisos/listar.php">Listar</a></li>
				<li class="noestilo"><a href="../pisos/insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="../pisos/borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="../pisos/buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="../pisos/modificar1.php">Modificar</a></li>

				<br>
				<a href='../../index.php'>Volver a página principal</a>


				
				<h1>Baja de usuarios </h1>
				<br>
				<p>Especifique <b>UN PARÁMETRO DEL USUARIO</b> para borrarlo:</p>
				<br>
				<form action="borrar2.php" method="get" >
					<p>Id del usuario: <input type="number" name="id" id="id" size="40"></p>
					<br>
					<p>Nombre del usuario: <input type="text" name="nombre" id="nombre" size="40"></p>
					<br>
					<p>Correo del usuario: <input type="text" name="correo" id="correo" size="40"></p>
					<br>
					<input type="submit" value="Enviar">
					<input type="reset" value="Borrar">
				</form></div>



</div>

</body>
</html>
