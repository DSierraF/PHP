<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Insertar</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../../estilos.css">
</head>
<body>
	


<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				<h3>Bienvenido al menú del administrador</h3>

				<br>

				<h4>Usarios:</h4>
				<li class="noestilo"><a href="listar.php">Listar</a></li>
				<li class="noestilo"><a href="insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="modificar1.php">Modificar</a></li>

				<br>

				<h4>Pisos:</h4>
				<li class="noestilo"><a href="../pisos/listar.php">Listar</a></li>
				<li class="noestilo"><a href="../pisos/insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="../pisos/borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="../pisos/buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="../pisos/modificar1.php">Modificar</a></li>

				<br>
				<a href='../../index.php'>Volver a página principal</a>


				
				<h1>Alta nuevo usuario</h1>
				<br>

				<form action="insertar2.php" method="get" >
				<p>* Nombre: <input type="text" name="usuario" id="usuario"></p> 
				<br>
				<p>* Correo: <input type="text" name="correo" id="correo"></p>
				<br>
				<p>* Contraseña: <input type="password" name="clave" id="clave"></p> <br>
				<p>* Tipo de usuario: 
				<input type="radio" name="tipouser" id="tipouser" value="comprador"> Comprador
				<input type="radio" name="tipouser" id="tipouser" value="vendedor"> Vendedor</p>
				<br>
				<p><b>Rellene los campos con un  *</b></p>
				<br>
				<input type="submit" name="enviar" value="Enviar">
				<input type="reset" value="Borrar">
				</form>
</div>



</div>

</body>
</html>