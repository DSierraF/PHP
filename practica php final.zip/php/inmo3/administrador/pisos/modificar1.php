<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Modificar</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../../estilos.css">
</head>
<body>

<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				<h3>Bienvenido al menú del administrador</h3>

				<br>

				<h4>Usarios:</h4>
				<li class="noestilo"><a href="../usuarios/listar.php">Listar</a></li>
				<li class="noestilo"><a href="../usuarios/insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="../usuarios/borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="../usuarios/buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="../usuarios/modificar1.php">Modificar</a></li>

				<br>

				<h4>Pisos:</h4>
				<li class="noestilo"><a href="listar.php">Listar</a></li>
				<li class="noestilo"><a href="insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="modificar1.php">Modificar</a></li>
				<br>
				<a href='../../index.php'>Volver a página principal</a>			
				<h1>Modificar piso</h1>
				<br>

				<form action="modificar2.php" method="get" >
				 <p>Código del piso: <input type="number" name="codigo"></p> 
				<br>
				<input type="submit" name="enviar" value="Enviar">
				<input type="reset" value="Borrar">
				</form>
</div>


</div>

</body>
</html>