<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Modificar</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../../estilos.css">
</head>
<body>

<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				<h3>Bienvenido al menú del administrador</h3>

				<br>

				<h4>Usarios:</h4>
				<li class="noestilo"><a href="../usuarios/listar.php">Listar</a></li>
				<li class="noestilo"><a href="../usuarios/insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="../usuarios/borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="../usuarios/buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="../usuarios/modificar1.php">Modificar</a></li>

				<br>

				<h4>Pisos:</h4>
				<li class="noestilo"><a href="listar.php">Listar</a></li>
				<li class="noestilo"><a href="insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="modificar1.php">Modificar</a></li>
				<br>
				<a href='../../index.php'>Volver a página principal</a>


				
				<h1>Modificar datos del piso</h1>
				<br>
				<?php 

				$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");



				$codigo=$_REQUEST['codigo'];

					$query= "SELECT * FROM pisos WHERE codigo_piso=$codigo";
					$result=mysqli_query($conexion, $query);

					if (mysqli_num_rows($result) > 0) {

						$row=mysqli_fetch_assoc($result);

						print("<h2>Datos</h2>");
						print("<br>");
						print("<form action='modificar3.php' enctype='multipart/form-data' method='post'>");

						print("<p>Código del piso: <input type='text' name='codigo' value=".$row['Codigo_piso']." readonly>");
						print("<br><br>");
						print("<p>Calle: <input type='text' name='calle' value=".$row['calle']." required></p>");
						print("<br>");
						print("<p>Número del edificio: <input type='number' name='numero' value=".$row['numero']." required></p>");
						print("<br>");
						print("<p>Número del piso: <input type='number' name='piso' value=".$row['piso']." required></p>");
						print("<br>");
						print("<p>Puerta: <input type='text' name='puerta' value=".$row['puerta']." required></p>");
						print("<br>");
						print("<p>Código postal: <input type='number' name='cp' value=".$row['cp']." required></p>");
						print("<br>");
						print("<p>Metros cuadrados del piso: <input type='number' name='metros' value=".$row['metros']." required></p>");
						print("<br>");
						print("<p>Zona localización del piso: <input type='text' name='zona' value=".$row['zona']." required></p>");
						print("<br>");
						print("<p>Precio: <input type='number' name='precio' value=".$row['precio']." required></p>");
						print("<br>");
						print("<p>Imagen: <a href='../../imagenes_pisos/".$row['imagen']."'target='_blank'>".$row['imagen']."</a></p>");
						print("<br>");
						print("<p>Cambiar imagen: <input type='file' name='imagen'></p>");
						print("<br>");
						print("<p>Id del usuario propietario: <input type='number' name='id' value=".$row['usuario_id']." required></p>");
						print("<br>");

						print("<input type='submit' value='Enviar'>");
						print("<input type='reset' value='Borrar'>");

						print("</form>");
					} else {
						print("No existe ese piso");
					}
					mysqli_close($conexion);
				?></div>



</div>

</body>
</html>



