<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Borrar</title>
	<link rel="stylesheet" type="text/css" href="../../estilos.css">
</head>
<body>

<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				<h3>Bienvenido al menú del administrador</h3>

				<br>

				<h4>Usarios:</h4>
				<li class="noestilo"><a href="../usuarios/listar.php">Listar</a></li>
				<li class="noestilo"><a href="../usuarios/insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="../usuarios/borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="../usuarios/buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="../usuarios/modificar1.php">Modificar</a></li>

				<br>

				<h4>Pisos:</h4>
				<li class="noestilo"><a href="listar.php">Listar</a></li>
				<li class="noestilo"><a href="insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="modificar1.php">Modificar</a></li>
				<br>
				<a href='../../index.php'>Volver a página principal</a>



				
				<?php 

				$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");



				$codigo=$_REQUEST['codigo'];

				$query = "DELETE FROM pisos WHERE codigo_piso=$codigo";

				if (mysqli_query($conexion,$query)) {
						print("Piso eliminado con éxito");
				} else {
					print("Fallo al eliminar el piso.");
				}
				mysqli_close($conexion);
				?></div>



</div>

</body>
</html>

