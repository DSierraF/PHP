<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Listar</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../../estilos.css">
</head>
<body>

<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				<h3>Bienvenido al menú del administrador</h3>

				<br>

				<h4>Usarios:</h4>
				<li class="noestilo"><a href="../usuarios/listar.php">Listar</a></li>
				<li class="noestilo"><a href="../usuarios/insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="../usuarios/borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="../usuarios/buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="../usuarios/modificar1.php">Modificar</a></li>

				<br>

				<h4>Pisos:</h4>
				<li class="noestilo"><a href="listar.php">Listar</a></li>
				<li class="noestilo"><a href="insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="modificar1.php">Modificar</a></li>
				<br>
				<a href='../../index.php'>Volver a página principal</a>


				
				<h1>Listado de pisos de la página</h1>
				<br><br>

				<?php 

				$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");



				$query = "SELECT * FROM pisos;";
				$resultado = mysqli_query($conexion, $query);

				if (mysqli_num_rows($resultado) > 0) {
					
					while ($row = mysqli_fetch_assoc($resultado)) {

					print("<ul class='listado'>");
					print("<li><b>Código del piso</b>: ".$row['Codigo_piso']." <b>Calle</b>: ".$row['calle']." <b>Número</b>: ".$row['numero']." <b>Piso</b>: ".$row['piso']." <b>Puerta</b>: ".$row['puerta']." <b>Código postal</b>: ".$row['cp']." <b>Metros</b>: ".$row['metros']." <b>Zona</b>: ".$row['zona']." <b>Precio</b>: ".$row['precio']." <b>Imagen</b>: ".$row['imagen']." <b>Id usuario propietario</b>: ".$row['usuario_id']."</li>");
					print("<br><br>");
					print("</ul>");

					}
				} else {
					echo "No hay datos";
				}
				mysqli_close($conexion);
				?></div>



</div>

</body>
</html>

