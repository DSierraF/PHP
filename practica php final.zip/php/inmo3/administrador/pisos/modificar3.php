<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Modificar</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../../estilos.css">
</head>
<body>

<div class="contenedor1">
	<div id="cabecera">

		<table>
			<tr>
				<td class="titulo">
					<h1><a class="inicio" href="../../index.php">Siefer Inmobiliarias</a></h1>
				</td>
				<td class="sesion">
					<p><a class="inicio" href="../../cerrar.php">Cerrar sesión</a></p>
				</td>
			</tr>
		</table>

	</div>

	<div class="prin">
				
				<h3>Bienvenido al menú del administrador</h3>

				<br>

				<h4>Usarios:</h4>
				<li class="noestilo"><a href="../usuarios/listar.php">Listar</a></li>
				<li class="noestilo"><a href="../usuarios/insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="../usuarios/borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="../usuarios/buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="../usuarios/modificar1.php">Modificar</a></li>

				<br>

				<h4>Pisos:</h4>
				<li class="noestilo"><a href="listar.php">Listar</a></li>
				<li class="noestilo"><a href="insertar1.php">Alta</a></li>
				<li class="noestilo"><a href="borrar1.php">Baja</a></li>
				<li class="noestilo"><a href="buscar1.php">Buscar</a></li>
				<li class="noestilo"><a href="modificar1.php">Modificar</a></li>
				<br>
				<a href='../../index.php'>Volver a página principal</a>


				
				<?php

				$conexion = mysqli_connect("localhost", "root", "css99");
				mysqli_select_db ($conexion, "inmobiliaria2") or die ("No se puede seleccionar la base de datos");



				$codigo=$_POST['codigo'];
				$calle=$_POST['calle'];
				$numero=$_POST['numero'];
				$piso=$_POST['piso'];
				$puerta=$_POST['puerta'];
				$cp=$_POST['cp'];
				$metros=$_POST['metros'];
				$zona=$_POST['zona'];
				$precio=$_POST['precio'];
				$usuario_id=$_POST['id'];
				$imagen=$_FILES['imagen']['name'];

				if (strlen("$imagen")==0) {

					$query = "UPDATE pisos SET calle='$calle', numero=$numero, piso=$piso, puerta='$puerta', cp=$cp, metros=$metros, zona='$zona', precio=$precio, usuario_id=$usuario_id WHERE codigo_piso=$codigo;";

					if (mysqli_query($conexion, $query)) {
						echo "Datos del pisos modificados correctamente.";
					} else {
						echo "Error al actualizar los datos del piso: ".mysqli_error($conexion);
					}
				}
				
				else {
					$directorio='../../imagenes_pisos/';
					$subirimagen=$directorio.basename($_FILES['imagen']['name']);
					if (move_uploaded_file($_FILES['imagen']['tmp_name'], $subirimagen)) {
						$query = "UPDATE pisos SET calle='$calle', numero=$numero, piso=$piso, puerta='$puerta', cp=$cp, metros=$metros, zona='$zona', precio=$precio, imagen='$imagen', usuario_id=$usuario_id WHERE codigo_piso=$codigo;";
					if (mysqli_query($conexion, $query)) {
						echo "Datos del piso modificados correctamente.";
					} else {
						echo "Error al actualizar los datos del piso: ".mysqli_error($conexion);
					}
				}
				}
				
				mysqli_close($conexion);
				?>

			</td>

		</tr>

	</table>



</div>

</body>
</html>