<html>
<head></head>

<body>
    <?php
    $x= 2;
    $y= 4;
    $suma=$x+$y;
    $multi= $x * $y;
    $potencia=pow($x,$y);
    echo "Suma: $x + $y= $suma <br> \n";
    echo "Multi: $x * $y= $multi <br> \n";
    echo "Potencia : $potencia <br> \n"
    ?>
</body>
</html>