
<html>
<head></head>

<body>
    <?php

$haydos = false;
for ($i=0;$i<3;$i++){
    $dado = rand(1,6);
    print "<p> Tirada de dado : $dado </p> \n";
    if ($dado == 2) {
        $haydos=true;
    }
}
if ($haydos){
    print "<p> Ha salido al menos un 2  </p> \n";
}
else {
    print "<p> No ha salido ningun 2  </p> \n";
}


    ?>
</body>
</html>