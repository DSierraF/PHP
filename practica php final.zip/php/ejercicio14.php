
<html>
<head>
<style>

    #resultado {
        border: 2px solid black;
        width: 5%;
        height: 5%;
        font-size: 25pt;
        text-align: center;
    }
</style>
</head>

<body>
    <?php

$contador=0;
for ($i=0;$i<2;$i++){
    $dado = rand(1,6);
    print "<img src='./img/$dado.jpg'</p> \n";
    $contador=$contador+$dado;
}


print "<div id=resultado>  $contador </div>\n";

    ?>
</body>
</html>