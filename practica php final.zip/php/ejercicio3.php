<html>
<head></head>

<body>
    <?php
    $cadena1 = "Barcelona";
    $cadena2 = "Palancas";
    $cadena3 = $cadena1 . " " . $cadena2;
    echo "$cadena3"
    ?>
</body>
</html>