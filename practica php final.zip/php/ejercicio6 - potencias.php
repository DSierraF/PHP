
<html>
<head></head>

<body>
    <?php
    define("pi",3.14);
    print "El valor de pi es ". pi . "<br> \n";

    $valor = 9;
    $valor++;
    echo "El valor es " . $valor++ . "<br> \n";
    echo "El valor es " .  $valor-- . "<br> \n";



    $numero=4.5;
    $numero1= round($numero);
    echo "Round ". $numero1 . "<br> \n";
    $numero2= floor($numero);
    echo "Floor ". $numero2 . "<br> \n";
    $numero3= ceil($numero);
    echo "Ceil ". $numero3 . "<br> \n";

    ?>
</body>
</html>