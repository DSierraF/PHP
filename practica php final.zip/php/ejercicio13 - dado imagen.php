
<html>
<head></head>

<body>
    <?php

$contador=0;
for ($i=0;$i<5;$i++){
    $dado = rand(1,6);
    print "<img src='./img/$dado.jpg'</p> \n";
    if ($dado == 4) {
        $contador++;
    }
}

print "<p> Mostramos el resultado:</p>\n";
print "<p> Han salido $contador veces el 4</p>\n";

    ?>
</body>
</html>