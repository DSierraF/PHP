
<html>
<head></head>

<body>
    <?php

print "<h1>  COMIENZO </h1> \n";

for  ($i=0; $i<=9; $i++) {
    print "<p> $i</p> \n";
}

print "<h1>  FINAL </h1> \n";

    ?>
</body>
</html>